# Bus-Tracking-System
An Introduction to the Bus Tracking System Prototype Project, which was displayed during the Shillong Hackathon 2017 by teamodysseus

## Members:
Melvin Star Majaw, Kyrshanlang R Dkhar, Kitborlang Lyngdoh, Sumit Kumar Hajong.

## Bus Tracking System Technical Specifications:
The System consist of:
1. An IOT device build on arduino (GPS + Wifi modules)
2. An Android Application for users, where they can view the current location of Buses in the app
3. A Backend Web Application for administrators
